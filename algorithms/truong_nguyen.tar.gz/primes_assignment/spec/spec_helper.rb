require_relative '../lib/problem1'
require_relative '../lib/problem2'
require_relative '../lib/look_prime'

RSpec.configure do |config|
end
