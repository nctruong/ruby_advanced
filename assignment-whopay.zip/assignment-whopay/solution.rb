# Main program
require "#{Dir.pwd}/config/configuration.rb"

if ARGV.size < 2
  Logger.log_instance.debug Mavericks::Message::Issue::LACK_FILE_PATH
  Logger.log_instance.debug Mavericks::Message::Issue::INSTRUCTION
elsif !File.exist?(ARGV.first)
  message = "#{ARGV.first} #{Mavericks::Message::Issue::FILE_NOT_EXISTED}"
  Logger.log_instance.debug message
elsif !File.exist?(ARGV[1])
  message = "#{ARGV[1]} #{Mavericks::Message::Issue::FILE_NOT_EXISTED}"
  Logger.log_instance.debug message
else
  solution = Mavericks::Transaction.new(ARGV.first, ARGV[1])
  print solution.results
end
