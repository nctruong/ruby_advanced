# Main module
module Mavericks
  # Base class for interfaces definition
  class Base
    def results
      raise NotImplementedError
    end
  end
end
