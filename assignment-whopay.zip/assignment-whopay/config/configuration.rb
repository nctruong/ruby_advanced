require 'logger'
require 'byebug'

require_relative '../lib/base.rb'
require_relative '../lib/logging.rb'
require_relative '../lib/amount.rb'
require_relative '../lib/transaction.rb'
require_relative '../lib/message.rb'
require_relative '../lib/logging.rb'
